library(brew)
setwd("/Applications/MAMP/htdocs/SOPBuilder/JSImagesR")
brew('scroll.html', output='viewer.html')